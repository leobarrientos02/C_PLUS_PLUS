#pragma once

int multiply(int num1, int num2);
